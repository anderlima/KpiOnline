<?php 
require_once("db_user.php");
require_once("user_logic.php");

$email = $_POST["email"];
$password = $_POST["password"];

$user = getUser($db, $email, $password);

if($user['bucket'] == "analista") {
  $level = "one";
	}elseif($user['bucket'] == "vintequatro"){
		$level = "two";
		}elseif($user['bucket'] == "dispatcher" || $user['bucket'] == "qa"){
			$level = "three";
			}else{
				$level = "four";
					}

if($user == null) {
	$_SESSION["danger"] = "Wrong user or password!";
	echo $user['email'];
	header("Location: login_page.php");
} else {

	$_SESSION["success"] = "User successfully logged in!";
	logUser($user['email'], $user['groups']);
	getPrivilege($level);

echo $user['email'];
	header("Location: index.php");
}
die();
?>
