<?php
try
  {

$db = new PDO('sqlite3:kpitest.sqlite');

}
catch(PDOException $e)
  {
    print 'Exception : '.$e->getMessage();
  }

?>
