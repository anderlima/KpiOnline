		</div>
	</div>
	<script type="text/javascript" src="js/users.js"></script>
	<script type="text/javascript" src="js/categories.js"></script>
	</body>
</html>