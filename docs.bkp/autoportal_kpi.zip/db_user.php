<?php
require_once("connect_db.php");

function getUser($db, $email, $password) {
	#   $passMd5 = md5($password);
    $sth = $db->prepare("select * from users where email= :email and password= :password");
    $sth->bindValue(':email', $email);
	$sth->bindValue(':password', $password);
	$sth->execute();
  	$result = $sth->fetch(PDO::FETCH_ASSOC);

return $result;
}