DROP TABLE IF EXISTS `categories`;

CREATE TABLE `categories` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `name` varchar(25) NOT NULL,
  `description` varchar(255) NOT NULL,
  `visibility` tinyint(1) NOT NULL
  );
  
  INSERT INTO `categories` VALUES (5,'Event/Netcool','Event/Netcool',1),(6,'HC','Health Checking',1),
(7,'24x7 Support','24x7 Support',1),(8,'Add Monitoring','Add Monitoring',1),(9,'Remove Monitoring','Remove Monitoring',1),
(10,'Meetings','Meetings',1),(11,'Access Request','Access Request',1),(12,'Investigation Actions','Investigation Actions',1),
(13,'Modify Monitoring','Modify Monitoring',1),(14,'RTEM Actions/issues','RTEM Actions/issues',1),(15,'Database Issues','Database Issues',1),
(16,'Documentation','Documentation',1),(17,'High space used general','High space used general',1),(18,'Chat','Chat',1),(19,'Help/Assist','Help/Assist',1);

DROP TABLE IF EXISTS customers;

CREATE TABLE customers (
  code varchar(3) NOT NULL PRIMARY KEY,
  name varchar(255) NOT NULL
);

INSERT INTO `customers` VALUES ('ALL','Ally'),('AMP','Ameriprise'),('DEN','Direct Energy from North Carolina');


DROP TABLE IF EXISTS kpis;

CREATE TABLE `kpis` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `users_email` varchar(45) NOT NULL,
  `bucket` varchar(45) NOT NULL,
  `agile_group` varchar(45) NOT NULL,
  `user_creator` varchar(45) NOT NULL,
  `creation_date` datetime NOT NULL,
  `closure_date` datetime DEFAULT NULL,
  `time_spent` double DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `num_server` int(3) NOT NULL,
  `external_ticket` varchar(15) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `slas_id` int(11) NOT NULL,
  `customers_code` varchar(3) NOT NULL,
  `tools_id` int(11) NOT NULL,
  `categories_id` int(11) NOT NULL,
  CONSTRAINT `kpi_category_fk` FOREIGN KEY (`categories_id`) REFERENCES `categories` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `kpi_customers_fk` FOREIGN KEY (`customers_code`) REFERENCES `customers` (`code`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `kpi_sla_fk` FOREIGN KEY (`slas_id`) REFERENCES `slas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `kpi_tools_fk` FOREIGN KEY (`tools_id`) REFERENCES `tools` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `kpi_users_fk` FOREIGN KEY (`users_email`) REFERENCES `users` (`email`) ON DELETE NO ACTION ON UPDATE NO ACTION
);

DROP TABLE IF EXISTS `slas`;

CREATE TABLE `slas` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `severity` int(11) NOT NULL,
  `sla` time(3) NOT NULL,
  `type` varchar(45) NOT NULL,
  `customers_code` varchar(3) NOT NULL,
  CONSTRAINT `sla_customers_fk` FOREIGN KEY (`customers_code`) REFERENCES `customers` (`code`) ON DELETE NO ACTION ON UPDATE NO ACTION
);

INSERT INTO `slas` VALUES (2,4,'80:00:00','WR','ALL'),(3,3,'40:00:00','WR','ALL'),
(4,2,'20:00:00','WR','ALL'),(5,1,'10:00:00','WR','ALL'),(6,1,'10:00:00','WR','AMP'),
(7,2,'20:00:00','WR','AMP'),(8,3,'30:00:00','WR','AMP'),(9,4,'40:00:00','WR','AMP'),
(10,1,'05:00:00','Incident','DEN'),(11,2,'24:00:00','Incident','DEN'),(12,3,'30:00:00','Incident','DEN'),
(13,4,'50:00:00','Incident','DEN'),(14,1,'05:00:00','Request','AMP'),(15,2,'120:00:00','Request','AMP'),
(16,1,'48:00:00','WREQUEST','ALL'),(17,2,'75:00:00','WREQUEST','ALL'),(18,3,'200:00:00','WREQUEST','ALL');


DROP TABLE IF EXISTS `tools`;

CREATE TABLE `tools` (
  `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  `name` varchar(25) NOT NULL,
  `description` varchar(255) NOT NULL
);

INSERT INTO `tools` VALUES (1,'Tivoli Monitoring','Tivoli teste'),(2,'Netcool','Netcool test'),(3,'TADDM','TADDM tool'),(4,'Tririga','Tririga teste');

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `email` varchar(45) NOT NULL PRIMARY KEY,
  `groups` varchar(45) NOT NULL,
  `bucket` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL
);

INSERT INTO `users` VALUES ('adm@br.ibm.com','I-EAU-BR-5','adm','123'),('analista@br.ibm.com','I-EAU-BR-5','analista','123'),
('anderson@br.ibm.com','I-EAU-BR-10','analista','123'),('dispatcher@br.ibm.com','I-EAU-BR03','dispatcher','123'),
('qa@br.ibm.com','I-EAU-BR02','qa','123'),('vintequatro@br.ibm.com','I-EAU-BR-10','vintequatro','123');


DROP TABLE IF EXISTS `users_support_customers`;

CREATE TABLE `users_support_customers` (
  `users_email` varchar(45) NOT NULL,
  `customers_code` varchar(3) NOT NULL,
  PRIMARY KEY (`users_email`,`customers_code`),
  CONSTRAINT `fk_users_has_customers_customers1` FOREIGN KEY (`customers_code`) REFERENCES `customers` (`code`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_has_customers_users1` FOREIGN KEY (`users_email`) REFERENCES `users` (`email`) ON DELETE NO ACTION ON UPDATE NO ACTION
);

DROP TABLE IF EXISTS `users_support_tools`;

CREATE TABLE `users_support_tools` (
  `users_email` varchar(45) NOT NULL,
  `tools_id` int(11) NOT NULL,
  PRIMARY KEY (`users_email`,`tools_id`),
  CONSTRAINT `fk_users_has_tools_tools1` FOREIGN KEY (`tools_id`) REFERENCES `tools` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_has_tools_users1` FOREIGN KEY (`users_email`) REFERENCES `users` (`email`) ON DELETE NO ACTION ON UPDATE NO ACTION
);

















