<?php
require_once("user_logic.php");

checkUser();

$lvl = $_SESSION["level"];

if ($lvl == "three" || $lvl =="four"){
	header('Location:searchdisp.php');
}

require_once("head$lvl.php");
require_once("db_lookup.php");
require_once("get_date.php");
require_once("db_kpi.php");
?>

<table class="table table-striped table-bordered">

		<tr>
			<td align="center"><b>KPI #</b></td>
			<td align="center"><b>YYYY-mm-dd</b></td>
			<td align="center"><b>Type</b></td>
			<td align="center"><b>Customer</b></td>
			<td align="center"><b>Tool</b></td>
			<td align="center"><b>Ticket</b></td>
			<td align="center"><b>Sev</b></td>
			<td align="center"><b>Description</b></td>
			<td align="center"><b>Status</b></td>
			</tr>
		<tr>
		<form action="searchanalyst.php" method="post">
			<td align="center"><input name="kpiid" type="text" class="form-control input-sm"></td>
			<td align="center"><input name="creation_date" type="text" class="form-control input-sm"></td>
			<td align="center"><input name="type" type="text" class="form-control input-sm"></td>
			<td align="center"><input name="customer" type="text" class="form-control input-sm"></td>
			<td align="center"><input name="tool" type="text" class="form-control input-sm"></td>
			<td align="center"><input name="ticket" type="text" class="form-control input-sm"></td>
			<td align="center"><input name="severity" type="text" class="form-control input-sm"></td>
			<td align="center"><input name="description" type="text" class="form-control input-sm"></td>
			<td align="center"><input name="status" type="text" class="form-control input-sm"></td>
			<button class="btn btn-sm btn-success" style="position: absolute; left: -9999px">Search</button>
		</form>
		</tr>
		<?php
			$kpiid = $_POST['kpiid'] ? $_POST['kpiid'] : "";
			$cdate = $_POST['creation_date'] ? $_POST['creation_date'] : "";
			$type = $_POST['type'] ? $_POST['type'] : "";
			$customer = $_POST['customer'] ? $_POST['customer'] : "";
			$tool = $_POST['tool'] ? $_POST['tool'] : "";
			$ticket = $_POST['ticket'] ? $_POST['ticket'] : "";
			$severity = $_POST['severity'] ? $_POST['severity'] : "";
			$description = $_POST['description'] ? $_POST['description'] : "";
			$status = $_POST['status'] ? $_POST['status'] : "";
			$users_email = Whois();
			
			if (startsWith("closed", strtolower($status)) == NULL){
					$real_status = 1;
				}elseif(startsWith("opened", strtolower($status)) == NULL){
							$real_status = 0;
					}else{
								$real_status = "";
						}


			$kpis = filterUserKPIs($db, $kpiid, $users_email, $cdate, $type, $customer, $tool, $ticket, $severity, $description, $real_status);
			foreach($kpis as $kpi) :
				$status_v = $kpi['status'] == 0 ? "Closed" : "Opened";
		?>
		<tr>
			<td align="center"><?= $kpi['id'] ?></td>
			<td align="center"><?= date('Y/m/d H:i:s', strtotime($kpi['creation_date'])) ?></td>
			<td align="center"><?= $kpi['type'] ?></td>
			<td align="center"><?= $kpi['c_name'] ?></td>
			<td align="center"><?= $kpi['t_name']?></td>
			<td align="center"><?= $kpi['external_ticket'] ?></td>
			<td align="center"><?= $kpi['severity'] ?></td>
			<td align="center"><?= $kpi['description'] ?></td>
			<td align="center"><?= $status_v ?></td>
			
		</tr>
		<?php
			endforeach
		?>	
</table>

<script type="text/javascript">
    $(".datetimepicker").datetimepicker({
        });
</script>

<?php include("footer.php"); ?>
